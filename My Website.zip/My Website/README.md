<h1 align="center">
    <img width="120" height="120" alt="Portfolio Alexa icon" width="200" src="https://user-images.githubusercontent.com/92635792/195620563-779ddc67-fd84-4b6c-9dd9-4d150579b3df.png" />
    <br><br>Responsive Portfolio Alexa Website<br />
</h1>

<img alt="Responsive Portfolio Alexa Website" src="https://user-images.githubusercontent.com/92635792/195621931-a5480585-cb0f-485e-b8e7-09a5ef0a9e2b.jpg" />


## :rocket: Technologies

Este projeto foi desenvolvido com as seguintes tecnologias:

-  HTML5
-  CSS3
-  Javascript
-  [GlideJS](https://glidejs.com/)
-  [VS Code](https://code.visualstudio.com/)


- Front End desenvolvido por [Marcial Garcia](https://www.linkedin.com/in/marcial-garcia/)
- Tutorial em vídeo do desenvolvimento no canal [MG Codes](https://youtu.be/1Q6YunLtIYY)
